package com.aryan.personalbox;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.net.Uri;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private WebView web;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new PhoneStorage(), "AndroidStorage");
        web.loadUrl("file:///android_asset/index.html");
    }

    public class PhoneStorage {
        @JavascriptInterface
        public String saveImage(String sourceUri, String fileName) {
            try {
                Uri src = Uri.parse(sourceUri);
                ContentResolver cr = getContentResolver();

                ContentValues v = new ContentValues();
                v.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
                v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ARYAN");
                v.put(MediaStore.Images.Media.IS_PENDING, 1);

                Uri dest = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                if (dest == null) return "ERROR";

                try (InputStream in = cr.openInputStream(src);
                     OutputStream out = cr.openOutputStream(dest)) {
                    if (in == null || out == null) return "ERROR";
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                }

                ContentValues done = new ContentValues();
                done.put(MediaStore.Images.Media.IS_PENDING, 0);
                cr.update(dest, done, null, null);
                return dest.toString();
            } catch (Exception e) {
                return "ERROR:" + e.getMessage();
            }
        }
    }

    @Override public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}

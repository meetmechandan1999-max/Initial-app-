FINAL ANDROID APP PROJECT

Open this folder in Android Studio and Build > Build APK(s).
MainActivity loads app/src/main/assets/index.html.
The supplied MainActivity includes WebView + JavaScript + MediaStore photo saving.
